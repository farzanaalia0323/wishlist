let products = [];
let wishlist = [];

// Fetch products from the server
async function fetchProducts() {
    try {
        const response = await fetch('/api/products');
        const data = await response.json();
        products = Array.isArray(data) ? data : [];
        displayProducts();
    } catch (error) {
        console.error('Error fetching products:', error);
        products = [];
        displayProducts();
    }
}

// Fetch wishlist items
async function fetchWishlist() {
    try {
        const response = await fetch('/api/wishlist');
        const data = await response.json();
        wishlist = Array.isArray(data) ? data : [];
        displayWishlist();
    } catch (error) {
        console.error('Error fetching wishlist:', error);
        wishlist = [];
        displayWishlist();
    }
}

// Display products in the grid
function displayProducts() {
    const productsContainer = document.getElementById('products');
    if (!Array.isArray(products) || products.length === 0) {
        productsContainer.innerHTML = '<p>No products available</p>';
        return;
    }
    
    productsContainer.innerHTML = products.map(product => `
        <div class="product-card">
            <img src="${product.image || 'placeholder.jpg'}" alt="${product.name}">
            <h3>${product.name}</h3>
            <p>$${product.price}</p>
            <p>${product.description}</p>
            <button onclick="addToWishlist('${product._id}')">Add to Wishlist</button>
        </div>
    `).join('');
}

// Display wishlist items
function displayWishlist() {
    const wishlistContainer = document.getElementById('wishlist-items');
    if (!Array.isArray(wishlist) || wishlist.length === 0) {
        wishlistContainer.innerHTML = '<p>Your wishlist is empty</p>';
        return;
    }

    wishlistContainer.innerHTML = wishlist.map(item => {
        const product = item.productId || {};
        return `
            <div class="product-card">
                <img src="${product.image || 'placeholder.jpg'}" alt="${product.name}">
                <h3>${product.name}</h3>
                <p>$${product.price}</p>
                <button onclick="removeFromWishlist('${item._id}')">Remove</button>
            </div>
        `;
    }).join('');
}

// Add item to wishlist
async function addToWishlist(productId) {
    try {
        const response = await fetch('/api/wishlist', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ productId })
        });
        
        if (!response.ok) {
            throw new Error('Failed to add to wishlist');
        }
        
        await fetchWishlist();
    } catch (error) {
        console.error('Error adding to wishlist:', error);
    }
}

// Remove item from wishlist
async function removeFromWishlist(wishlistItemId) {
    try {
        const response = await fetch(`/api/wishlist/${wishlistItemId}`, {
            method: 'DELETE'
        });
        
        if (!response.ok) {
            throw new Error('Failed to remove from wishlist');
        }
        
        await fetchWishlist();
    } catch (error) {
        console.error('Error removing from wishlist:', error);
    }
}

// Toggle wishlist sidebar
function toggleWishlist() {
    const wishlistElement = document.getElementById('wishlist');
    wishlistElement.classList.toggle('hidden');
}

// Initial load
document.addEventListener('DOMContentLoaded', () => {
    fetchProducts();
    fetchWishlist();
});