const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const port = 3000;

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/shopping');

// Middleware
app.use(bodyParser.json());
app.use(express.static('public'));

// Product Schema
const productSchema = new mongoose.Schema({
  name: String,
  price: Number,
  description: String,
  image: String
});

// Wishlist Schema
const wishlistSchema = new mongoose.Schema({
  productId: { type: mongoose.Schema.Types.ObjectId, ref: 'Product' }
});

const Product = mongoose.model('Product', productSchema);
const Wishlist = mongoose.model('Wishlist', wishlistSchema);

// Routes
app.get('/api/products', async (req, res) => {
  try {
    const products = await Product.find();
    res.json(products);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching products' });
  }
});

app.get('/api/wishlist', async (req, res) => {
  try {
    const wishlist = await Wishlist.find().populate('productId');
    res.json(wishlist);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching wishlist' });
  }
});

app.post('/api/wishlist', async (req, res) => {
  try {
    const { productId } = req.body;
    const wishlistItem = new Wishlist({ productId });
    await wishlistItem.save();
    res.json({ message: 'Added to wishlist' });
  } catch (error) {
    res.status(500).json({ error: 'Error adding to wishlist' });
  }
});

app.delete('/api/wishlist/:id', async (req, res) => {
  try {
    await Wishlist.findByIdAndDelete(req.params.id);
    res.json({ message: 'Removed from wishlist' });
  } catch (error) {
    res.status(500).json({ error: 'Error removing from wishlist' });
  }
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});